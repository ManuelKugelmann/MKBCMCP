# Auth Decision: Query Parameter Token

**Date**: 2026-02-28
**Status**: Decided
**Context**: Single-user MCP server on Uberspace shared hosting

## The Problem

MCP spec requires **OAuth 2.1 + Dynamic Client Registration (RFC 7591)**.
DCR means any MCP client must auto-register without manual setup.

**Google and GitHub do not support DCR** — they require manual OAuth app creation in their web UI.

This means you cannot "just use Google/GitHub OAuth directly." You need an intermediary OAuth server that implements DCR.

## Options Evaluated

| Approach | Code | Dependencies | Fits Uberspace? |
|----------|------|--------------|-----------------|
| `?token=SECRET` | ~5 lines | 0 | ✅ |
| Cloudflare Workers OAuth | ~50 lines | CF Workers | ❌ wrong platform |
| `giantswarm/mcp-oauth` (Go) | ~30 lines | Go binary | ⚠ different runtime |
| `mcp-oauth-gateway` (Docker) | config | Docker + Traefik | ❌ no Docker |
| Auth0 + Express proxy | ~100 lines | Auth0 account | ⚠ external service |
| Roll-your-own OAuth 2.1 + DCR | ~500+ lines | Node.js | ⚠ security-critical |

### OAuth Library Deep-Dive

**Cloudflare Workers OAuth Provider** — Cleanest turnkey. But requires Cloudflare Workers deployment, not Uberspace.
- https://developers.cloudflare.com/agents/model-context-protocol/authorization/

**giantswarm/mcp-oauth (Go)** — Provider-agnostic OAuth 2.1 lib. ~30 lines to wire up. But requires Go binary on Uberspace (not Node.js) and still needs a GitHub/Google OAuth App manually registered.
- https://github.com/giantswarm/mcp-oauth

**mcp-oauth-gateway (Docker)** — Zero-modification OAuth layer. But requires Docker + Traefik (no Docker on Uberspace shared hosting).
- https://github.com/atrawog/mcp-oauth-gateway

**NapthaAI/http-oauth-mcp-server (Express + Auth0)** — Reference implementation. Requires Auth0 account (supports DCR). ~100+ lines Express middleware.
- https://github.com/NapthaAI/http-oauth-mcp-server

## Security Analysis: Query Param Token

### What's secure

- **HTTPS encrypts full URI** including query params (TLS 1.2+)
- **Apache default LogFormat** (`%h %l %u %t "%r" %>s %b`) does **not** log query strings (no `%q`)
- **Uberspace uses standard Apache config** → query params not in access logs
- **128-bit random token** = 2^128 combinations (unguessable)
- **Origin validation** blocks DNS rebinding attacks
- **URL stored by Anthropic** in claude.ai settings (same trust model as OAuth tokens)

### What's not

- URL in browser history (but Claude MCP connector is server-side, not browser)
- URL in Referer header (mitigated: `Referrer-Policy: no-referrer`)
- Same trust as webhook URLs (ntfy, GitHub webhooks all use this pattern)

### Comparison

```
Query Param (?token=SECRET)          OAuth 2.1 + GitHub IDP
─────────────────────────            ─────────────────────────
5 lines auth code                    500+ lines or Go binary
0 dependencies                       GitHub OAuth App registration
Works on Uberspace as-is             Needs Go/Docker/CF Workers
Secure for 1 user                    "Proper" for multi-user
URL = credential                     Token refresh, scopes
Same trust as webhook URLs           Same trust as SaaS
```

### Client Compatibility

| Method | claude.ai web/mobile | Claude Code | Claude API |
|--------|---------------------|-------------|------------|
| Query param (`?token=xxx`) | ✅ | ✅ | ✅ |
| Bearer header | ❌ web can't set | ✅ | ✅ |
| OAuth 2.1 + DCR | ✅ native flow | ✅ | ✅ |

## Decision

**Use query parameter token** for Phase 2 MCP, **Basic Auth** for Phase 1 gh-bootstrap.

**Rationale**:
- Single-user personal server, not multi-tenant SaaS
- Zero dependencies constraint (Node.js only on Uberspace)
- All OAuth options require Go binary, Docker, Cloudflare Workers, or Auth0
- None fit the constraint set
- Query param is secure enough for this use case
- Same security model as existing ntfy webhook setup

## Future Migration

If multi-user support ever needed:
1. `giantswarm/mcp-oauth` (Go) is least painful "real" OAuth
2. Requires different runtime (Go vs Node.js) + GitHub OAuth App registration
3. Or move to Cloudflare Workers entirely
