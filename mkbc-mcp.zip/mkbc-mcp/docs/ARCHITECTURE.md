# Architecture

## Overview

mkbc-mcp is a personal MCP server for bootstrapping GitHub repos from Claude conversations. It runs on Uberspace shared hosting with zero external dependencies (Node.js stdlib only).

## Phase 1: gh-bootstrap (Current)

Custom HTTP API with basic auth and ntfy push notifications.

```
Claude App (mobile/web)
  │ Share CLAUDE.md text
  ▼
AutoShare → Tasker → HTTP POST
  │
  ▼
Uberspace: gh-bootstrap (:9876)
  ├─ POST /gh/bootstrap
  │   ├─ Validate auth + rate limit
  │   ├─ Create repo (if new) via GitHub API
  │   ├─ Push CLAUDE.md
  │   └─ Fire ntfy notification → Android
  │
  └─ GET /gh/status (no auth)
```

### Alternative: Direct from Claude Chat

```bash
curl -su user:pass https://host.uber.space/gh/bootstrap \
  -H 'Content-Type: application/json' \
  -d '{"name":"my-project","claude_md":"# my-project\n..."}'
```

## Phase 2: mkbc-mcp (Planned)

MCP JSON-RPC 2.0 server, compatible with Claude's native MCP connector.

```
Claude (web/mobile/desktop)
  │ MCP Streamable HTTP
  ▼
Uberspace: mkbc-mcp (:8009) /mcp
  │
  ├─ POST /mcp  (JSON-RPC 2.0)
  │   ├─ initialize         → capabilities + session ID
  │   ├─ tools/list          → tool definitions
  │   ├─ tools/call          → execute tool
  │   └─ notifications/*     → 202 (no body)
  │
  └─ HEAD /mcp → MCP-Protocol-Version: 2025-06-18
```

### MCP Tools (Day 1)

| Tool | Params | Source |
|------|--------|--------|
| `bootstrap_repo` | `name`, `description`, `template?` | gh-bootstrap core |
| `push_file` | `repo`, `path`, `content`, `message?` | GitHub API |
| `list_repos` | `limit?` | GitHub API |
| `send_notification` | `title`, `message`, `priority?` | ntfy relay |

### MCP Transport

Streamable HTTP per MCP spec 2025-06-18:
- Single `/mcp` endpoint, all tools via JSON-RPC `tools/call`
- `Mcp-Session-Id` header on responses after init
- `Origin` header validation (DNS rebinding protection)
- 202 for notifications (requests without `id` field)
- 405 + `Allow: POST` for GET requests
- No SSE needed (all tools are fast, no streaming)

### Auth Strategy

Claude.ai supports authless remote MCP → URL in Settings > Connectors.

For Phase 2, query parameter token:

```
https://host.uber.space/mcp?token=SECRET_128BIT_RANDOM
```

Rationale: See [AUTH-DECISION.md](AUTH-DECISION.md).

## Uberspace Infrastructure

```
Apache (TLS termination, *.uber.space cert)
  ├─ /gh/*  → localhost:9876 (gh-bootstrap)
  ├─ /mcp   → localhost:8009 (mkbc-mcp, future)
  └─ /*     → localhost:8008 (ntfy web UI + API)

Supervisord
  ├─ gh-bootstrap.ini
  ├─ ntfy.ini
  └─ [future] mkbc-mcp.ini
```

### Port Allocation

| Service | Port | Web Backend |
|---------|------|-------------|
| ntfy | 8008 | `/ → :8008` |
| mkbc-mcp | 8009 | `/mcp → :8009` (future) |
| gh-bootstrap | 9876 | `/gh → :9876` |

## Notification Flow

```
gh-bootstrap
  │ HTTP POST (fire-and-forget)
  ▼
ntfy (localhost:8008)
  │ upstream → ntfy.sh (for push delivery)
  ▼
📱 Android ntfy app
  ┌─────────────────────────────────┐
  │ gh-bootstrap                    │
  │ 🆕 Created: sensor-api         │
  │ https://github.com/.../...      │
  │ 1234 chars, 3/15 today         │
  └─────────────────────────────────┘
```

### Notification Events

| Event | Tags | Priority |
|-------|------|----------|
| Repo created | `new` | default |
| Repo updated | `pencil` | default |
| Bootstrap failed | `warning` | high |

## Security Model

- HTTPS everywhere (Uberspace Let's Encrypt)
- Basic Auth for Phase 1 / Query param token for Phase 2
- IP ban: 5 auth failures in 15min → blocked 1h
- Rate limit: configurable creates/day (default 15)
- Origin validation (Phase 2 MCP)
- ntfy: deny-all default, admin user + access token
- Fine-grained GitHub PAT (repo create + contents write only)
