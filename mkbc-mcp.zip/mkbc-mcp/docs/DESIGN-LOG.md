# Design Log

Chronological record of design sessions that produced this project.

## 2026-02-28 Session 1: Bootstrap Workflow

**Topics**: Project bootstrap concept, Tasker automation, ntfy.sh approval notifications.

- Designed flow: Claude App → Share → AutoShare/Tasker → GitHub API → repo created
- Evaluated notification options: ntfy.sh (winner), Tasker+AutoRemote, PWA+WebPush
- Decided: self-host ntfy on Uberspace (not hosted ntfy.sh)
- Designed approval flow: long-poll pattern with ntfy action buttons
- Produced first gh-bootstrap.js (HTTP API, basic auth, GitHub Contents API)

## 2026-02-28 Session 2: Cross-Provider Memory Sync

**Topics**: Mem0 OpenMemory, MCP servers, Claude mobile MCP support.

- Explored cross-provider LLM memory sync (ChatGPT, Claude, Gemini, Perplexity)
- Identified MCP as the integration path for Claude mobile/web/desktop
- Decided: Streamable HTTP transport (MCP spec 2025-06-18), single `/mcp` endpoint

## 2026-02-28 Session 3: MCP Architecture

**Topics**: Rename to mkbc-mcp, auth strategy, tool definitions.

- Renamed: gh-bootstrap → mkbc-mcp (Manuel Kugelmann Bootstrap Claude MCP)
- Evaluated auth: authless vs OAuth vs Bearer vs query param
- Discovered: claude.ai natively supports authless remote MCP
- Defined Day 1 tools: bootstrap_repo, push_file, list_repos, send_notification
- Architecture: port 8009, /mcp endpoint, JSON-RPC 2.0

## 2026-02-28 Session 4: OAuth Deep-Dive

**Topics**: OAuth 2.1 + DCR analysis, library comparison.

- Core problem: MCP requires Dynamic Client Registration (RFC 7591)
- Google/GitHub don't support DCR → need intermediary OAuth server
- Evaluated 5 OAuth approaches (Cloudflare, giantswarm, mcp-oauth-gateway, Auth0, DIY)
- None fit: Uberspace shared hosting + zero deps + Node.js only
- **Decision**: Query parameter token for auth. OAuth rejected.

## 2026-03-03 Session 5: Final Implementation

**Topics**: ntfy integration, deployment scripts, packaging.

- Integrated ntfy fire-and-forget notifications into gh-bootstrap.js
- Created comprehensive setup-uberspace.sh deployment script
- Added DAILY_LIMIT env var (configurable rate limit)
- Documented full auth decision rationale
- Created deployment package for GitHub repo
