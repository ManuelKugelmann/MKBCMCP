# MCP Migration Plan

## Phase 1 → Phase 2

```diff
- HTTP REST API (custom routes)
+ MCP JSON-RPC 2.0 (single /mcp endpoint)

- Basic Auth (AUTH_USER/AUTH_PASS)
+ Query param token (?token=SECRET) or Authless (Origin validation only)

- Port 9876, /gh/* routes
+ Port 8009, /mcp endpoint

- /gh/bootstrap, /gh/status endpoints
+ /mcp endpoint (all tools via tools/call)
```

## MCP Protocol Requirements

### Spec: 2025-06-18 (Streamable HTTP)

Single `/mcp` endpoint handles everything via JSON-RPC 2.0:

```
POST /mcp
  Content-Type: application/json
  Mcp-Session-Id: <session-id>    (after init)

  { "jsonrpc": "2.0", "id": 1, "method": "initialize", "params": {...} }
```

### Required Server Behaviors

1. **initialize** → Return capabilities, protocol version, session ID
2. **notifications/initialized** → Return 202 (no body)
3. **tools/list** → Return tool definitions with JSON Schema params
4. **tools/call** → Execute tool, return result
5. **HEAD /mcp** → `MCP-Protocol-Version: 2025-06-18`
6. **GET /mcp** → `405 Method Not Allowed` + `Allow: POST`
7. **Origin validation** on every request

### Tool Definition Format

```json
{
  "name": "bootstrap_repo",
  "description": "Create a GitHub repo and push CLAUDE.md",
  "inputSchema": {
    "type": "object",
    "properties": {
      "name": { "type": "string", "description": "Repo name (lowercase, a-z0-9, hyphens)" },
      "description": { "type": "string", "description": "Repo description" },
      "claude_md": { "type": "string", "description": "CLAUDE.md content" },
      "public": { "type": "boolean", "default": true }
    },
    "required": ["name", "claude_md"]
  }
}
```

### Session Management

- Generate UUID session ID on `initialize`
- Return `Mcp-Session-Id` header on all subsequent responses
- Validate session on all requests after init
- Sessions are ephemeral (in-memory Map, no persistence needed)

## Implementation Skeleton

```
mkbc-mcp.js (~300-400 lines estimated)
├── MCP protocol handler (JSON-RPC 2.0 router)
├── Session manager (in-memory Map)
├── Origin validator
├── Auth middleware (query param token)
├── Tool registry
│   ├── bootstrap_repo  (from gh-bootstrap)
│   ├── push_file       (new)
│   ├── list_repos      (new)
│   └── send_notification (ntfy relay)
└── GitHub API client   (reuse from gh-bootstrap)
```

## Claude.ai Setup

After deployment:

1. Settings → Connectors → Add MCP
2. URL: `https://kugelmann.uber.space/mcp?token=YOUR_SECRET`
3. Done — syncs to mobile automatically

## Deployment

```bash
# Web backend
uberspace web backend set /mcp --http --port 8009

# Supervisord
cat > ~/etc/services.d/mkbc-mcp.ini << 'EOF'
[program:mkbc-mcp]
directory=%(ENV_HOME)s/mkbc-mcp
command=node %(ENV_HOME)s/mkbc-mcp/mkbc-mcp.js
autostart=true
autorestart=true
startsecs=5
environment=
    GITHUB_PAT="...",
    GITHUB_OWNER="ManuelKugelmann",
    PORT="8009",
    MCP_TOKEN="...",
    NTFY_URL="http://localhost:8008",
    NTFY_TOPIC="mkbc-mcp",
    NTFY_TOKEN="..."
EOF
```

## Coexistence

During migration, both can run simultaneously:
- `/gh/*` → gh-bootstrap (port 9876) — Phase 1
- `/mcp` → mkbc-mcp (port 8009) — Phase 2
- `/*` → ntfy (port 8008) — shared

Phase 1 can be retired once Phase 2 is stable.

## References

- MCP Spec (Streamable HTTP): https://modelcontextprotocol.io/specification/2025-06-18/basic/transports#streamable-http
- MCP Auth Spec: https://modelcontextprotocol.io/specification/2025-06-18/basic/authorization
- Claude MCP Connectors: Settings → Connectors in claude.ai
