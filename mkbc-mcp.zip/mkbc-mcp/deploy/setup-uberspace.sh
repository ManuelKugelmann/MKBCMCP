#!/bin/bash
# setup-uberspace.sh — Complete deployment of gh-bootstrap + self-hosted ntfy
#
# Usage:
#   1. Edit CONFIG section below
#   2. scp this file + gh-bootstrap.js to Uberspace
#   3. ssh to Uberspace, run: bash setup-uberspace.sh
#
set -euo pipefail

# ── CONFIG (edit these) ──────────────────────────────
GITHUB_PAT="ghp_REPLACE_ME"
GITHUB_OWNER="ManuelKugelmann"
AUTH_USER="REPLACE_ME"
AUTH_PASS="REPLACE_ME"
NTFY_ADMIN_USER="admin"
NTFY_ADMIN_PASS="REPLACE_ME"
NTFY_TOPIC="gh-bootstrap"
NTFY_VERSION="2.17.0"
GH_BOOTSTRAP_PORT=9876
NTFY_PORT=8008
DAILY_LIMIT=15
# ─────────────────────────────────────────────────────

# ── Colors ───────────────────────────────────────────
R='\033[0;31m' G='\033[0;32m' Y='\033[1;33m' B='\033[0;34m' C='\033[0;36m' NC='\033[0m'
ok()   { echo -e "${G}✓${NC} $1"; }
info() { echo -e "${B}▸${NC} $1"; }
warn() { echo -e "${Y}⚠${NC} $1"; }
err()  { echo -e "${R}✗${NC} $1"; exit 1; }

echo -e "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${C}  gh-bootstrap + ntfy — Uberspace deployment${NC}"
echo -e "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo

# ── Validate ─────────────────────────────────────────
[[ "$GITHUB_PAT" == "ghp_REPLACE_ME" ]] && err "Edit GITHUB_PAT in CONFIG section"
[[ "$AUTH_PASS" == "REPLACE_ME" ]] && err "Edit AUTH_PASS in CONFIG section"
[[ "$NTFY_ADMIN_PASS" == "REPLACE_ME" ]] && err "Edit NTFY_ADMIN_PASS in CONFIG section"

HOSTNAME=$(hostname)
BASE_URL="https://${HOSTNAME}"

# ── 1. ntfy binary ───────────────────────────────────
info "Installing ntfy v${NTFY_VERSION}..."
mkdir -p ~/ntfy/server ~/ntfy/attachments

if [[ -f ~/ntfy/ntfy ]]; then
  ok "ntfy binary already exists"
else
  wget -qO /tmp/ntfy.tar.gz \
    "https://github.com/binwiederhier/ntfy/releases/download/v${NTFY_VERSION}/ntfy_${NTFY_VERSION}_linux_amd64.tar.gz"
  tar --strip-components=1 -xzf /tmp/ntfy.tar.gz -C ~/ntfy/
  rm /tmp/ntfy.tar.gz
  chmod +x ~/ntfy/ntfy
  ok "ntfy v${NTFY_VERSION} installed"
fi

# ── 2. ntfy config ───────────────────────────────────
info "Writing ntfy server config..."
cat > ~/ntfy/server/server.yml << EOF
base-url: ${BASE_URL}
listen-http: ":${NTFY_PORT}"
cache-file: /home/$(whoami)/ntfy/cache.db
cache-duration: "12h"
auth-file: "/home/$(whoami)/ntfy/auth.db"
auth-default-access: "deny-all"
behind-proxy: true
attachment-cache-dir: "/home/$(whoami)/ntfy/attachments"
attachment-total-size-limit: "1G"
attachment-file-size-limit: "1M"
attachment-expiry-duration: "3h"
keepalive-interval: "45s"
manager-interval: "2m"
web-root: /
upstream-base-url: "https://ntfy.sh"
visitor-subscription-limit: 30
log-level: INFO
EOF
ok "ntfy config written"

# ── 3. ntfy admin user ──────────────────────────────
info "Setting up ntfy admin user..."
# Remove existing user if any, then recreate
~/ntfy/ntfy user --config ~/ntfy/server/server.yml del "${NTFY_ADMIN_USER}" 2>/dev/null || true
echo -e "${NTFY_ADMIN_PASS}\n${NTFY_ADMIN_PASS}" | \
  ~/ntfy/ntfy user --config ~/ntfy/server/server.yml add --role=admin "${NTFY_ADMIN_USER}" 2>/dev/null
ok "ntfy admin user '${NTFY_ADMIN_USER}' created"

# Generate access token for gh-bootstrap → ntfy
info "Generating ntfy access token..."
TOKEN_OUTPUT=$(~/ntfy/ntfy token --config ~/ntfy/server/server.yml add "${NTFY_ADMIN_USER}" 2>&1)
NTFY_ACCESS_TOKEN=$(echo "$TOKEN_OUTPUT" | grep -oP 'tk_\w+' | head -1)
if [[ -z "$NTFY_ACCESS_TOKEN" ]]; then
  warn "Could not extract token automatically. Check: ~/ntfy/ntfy token --config ~/ntfy/server/server.yml list"
  NTFY_ACCESS_TOKEN="MANUAL_TOKEN_NEEDED"
else
  ok "ntfy token: ${NTFY_ACCESS_TOKEN}"
fi

# ── 4. gh-bootstrap ─────────────────────────────────
info "Setting up gh-bootstrap..."
mkdir -p ~/gh-bootstrap

if [[ -f ~/gh-bootstrap.js ]]; then
  mv ~/gh-bootstrap.js ~/gh-bootstrap/gh-bootstrap.js
  ok "Moved gh-bootstrap.js into place"
elif [[ -f ~/gh-bootstrap/gh-bootstrap.js ]]; then
  ok "gh-bootstrap.js already in place"
else
  err "gh-bootstrap.js not found! Upload it first: scp gh-bootstrap.js ${HOSTNAME}:~/"
fi

# ── 5. Supervisord configs ──────────────────────────
info "Writing supervisord configs..."
mkdir -p ~/etc/services.d

cat > ~/etc/services.d/ntfy.ini << EOF
[program:ntfy]
command=%(ENV_HOME)s/ntfy/ntfy serve --config %(ENV_HOME)s/ntfy/server/server.yml
autostart=true
autorestart=true
startsecs=5
EOF

cat > ~/etc/services.d/gh-bootstrap.ini << EOF
[program:gh-bootstrap]
directory=%(ENV_HOME)s/gh-bootstrap
command=node %(ENV_HOME)s/gh-bootstrap/gh-bootstrap.js
autostart=true
autorestart=true
startsecs=5
environment=
    GITHUB_PAT="${GITHUB_PAT}",
    GITHUB_OWNER="${GITHUB_OWNER}",
    AUTH_USER="${AUTH_USER}",
    AUTH_PASS="${AUTH_PASS}",
    PORT="${GH_BOOTSTRAP_PORT}",
    DAILY_LIMIT="${DAILY_LIMIT}",
    NTFY_URL="http://localhost:${NTFY_PORT}",
    NTFY_TOPIC="${NTFY_TOPIC}",
    NTFY_TOKEN="${NTFY_ACCESS_TOKEN}"
EOF
ok "Supervisord configs written"

# ── 6. Web backends ─────────────────────────────────
info "Registering web backends..."
uberspace web backend set /gh --http --port ${GH_BOOTSTRAP_PORT} 2>/dev/null || true
uberspace web backend set / --http --port ${NTFY_PORT} 2>/dev/null || true
ok "Web backends: /gh → :${GH_BOOTSTRAP_PORT}, / → :${NTFY_PORT}"

# ── 7. Start services ───────────────────────────────
info "Starting services..."
supervisorctl reread
supervisorctl update
supervisorctl restart ntfy 2>/dev/null || supervisorctl start ntfy
sleep 2
supervisorctl restart gh-bootstrap 2>/dev/null || supervisorctl start gh-bootstrap
sleep 2
ok "Services started"

# ── 8. Verify ────────────────────────────────────────
info "Verifying..."

# ntfy health
NTFY_HEALTH=$(curl -sf "http://localhost:${NTFY_PORT}/v1/health" 2>/dev/null || echo "FAIL")
if echo "$NTFY_HEALTH" | grep -q "healthy"; then
  ok "ntfy healthy"
else
  warn "ntfy health check failed: ${NTFY_HEALTH}"
fi

# gh-bootstrap health
GH_STATUS=$(curl -sf "http://localhost:${GH_BOOTSTRAP_PORT}/gh/status" 2>/dev/null || echo "FAIL")
if echo "$GH_STATUS" | grep -q '"ok":true'; then
  ok "gh-bootstrap healthy"
else
  warn "gh-bootstrap health check failed: ${GH_STATUS}"
fi

# Test notification
info "Sending test notification..."
curl -sf \
  -H "Authorization: Bearer ${NTFY_ACCESS_TOKEN}" \
  -H "Title: Setup Complete" \
  -H "Tags: white_check_mark" \
  -d "gh-bootstrap + ntfy deployed on ${HOSTNAME}" \
  "http://localhost:${NTFY_PORT}/${NTFY_TOPIC}" > /dev/null 2>&1 && \
  ok "Test notification sent" || warn "Test notification failed"

# ── Summary ──────────────────────────────────────────
echo
echo -e "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo -e "${G}  Deployment complete!${NC}"
echo -e "${C}━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━${NC}"
echo
echo -e "  ${B}gh-bootstrap API${NC}:  ${BASE_URL}/gh/bootstrap"
echo -e "  ${B}gh-bootstrap status${NC}: ${BASE_URL}/gh/status"
echo -e "  ${B}ntfy web UI${NC}:        ${BASE_URL}"
echo -e "  ${B}ntfy topic${NC}:         ${BASE_URL}/${NTFY_TOPIC}"
echo -e "  ${B}ntfy token${NC}:         ${NTFY_ACCESS_TOKEN}"
echo
echo -e "  ${Y}Android ntfy app${NC}:"
echo -e "    Default server: ${BASE_URL}"
echo -e "    User: ${NTFY_ADMIN_USER}"
echo -e "    Subscribe to: ${NTFY_TOPIC}"
echo
echo -e "  ${Y}Test${NC}:"
echo -e "    curl -su ${AUTH_USER}:${AUTH_PASS} ${BASE_URL}/gh/bootstrap \\"
echo -e "      -H 'Content-Type: application/json' \\"
echo -e "      -d '{\"name\":\"test-repo\",\"claude_md\":\"# test\\nHello world\"}'"
echo
echo -e "  ${Y}Logs${NC}:"
echo -e "    supervisorctl tail -f gh-bootstrap"
echo -e "    supervisorctl tail -f ntfy"
echo
