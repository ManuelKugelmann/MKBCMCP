# mkbc-mcp

**Manuel Kugelmann Bootstrap Claude MCP** — Personal MCP server for bootstrapping GitHub repos and sending notifications from Claude (web, mobile, desktop).

## Status

| Component | State |
|-----------|-------|
| `gh-bootstrap` | ✅ Working — HTTP API, basic auth, ntfy notifications |
| `mkbc-mcp` | 🔲 Planned — MCP JSON-RPC 2.0 wrapper around gh-bootstrap tools |
| ntfy (self-hosted) | ✅ Working — Uberspace, Android push notifications |

## Architecture

```
Claude (web/mobile/desktop)
  │ [Phase 1: HTTP + Basic Auth]
  │ [Phase 2: MCP Streamable HTTP + authless/query param]
  ▼
Uberspace (kugelmann.uber.space)
  ├─ gh-bootstrap (port 9876) → /gh/*
  │   ├─ POST /gh/bootstrap  — create repo + push CLAUDE.md
  │   └─ GET  /gh/status     — health check
  │
  ├─ ntfy (port 8008) → /*
  │   └─ self-hosted push notifications → Android
  │
  └─ [future] mkbc-mcp (port 8009) → /mcp
      ├─ tool: bootstrap_repo
      ├─ tool: push_file
      ├─ tool: list_repos
      └─ tool: send_notification
```

## Quick Start

```bash
# 1. Edit deploy/setup-uberspace.sh CONFIG section
# 2. Upload to Uberspace
scp gh-bootstrap/gh-bootstrap.js deploy/setup-uberspace.sh you@yourhost.uberspace.de:~/

# 3. Run setup
ssh you@yourhost.uberspace.de bash setup-uberspace.sh

# 4. Test
curl -s https://yourhost.uberspace.de/gh/status
```

## Usage

```bash
curl -s -u user:pass https://yourhost.uberspace.de/gh/bootstrap \
  -H 'Content-Type: application/json' \
  -d '{
    "name": "my-project",
    "claude_md": "# my-project\nFastAPI service for...",
    "description": "A new project",
    "public": true
  }'
```

## Repo Structure

```
├── README.md
├── gh-bootstrap/
│   └── gh-bootstrap.js        # HTTP API server (Node 20+, zero deps)
├── deploy/
│   ├── setup-uberspace.sh     # Full deployment script (ntfy + gh-bootstrap)
│   ├── gh-bootstrap.ini       # Supervisord config template
│   └── ntfy-server.yml        # ntfy config template
└── docs/
    ├── ARCHITECTURE.md         # Architecture decisions & diagrams
    ├── AUTH-DECISION.md        # OAuth vs query param analysis
    └── MCP-MIGRATION.md        # Phase 2: migration to MCP protocol
```

## Key Decisions

- **Auth**: Query parameter token (Phase 2) / Basic Auth (Phase 1) — OAuth rejected as too complex for single-user on shared hosting. See [docs/AUTH-DECISION.md](docs/AUTH-DECISION.md).
- **Transport**: Streamable HTTP (MCP spec 2025-06-18), single `/mcp` endpoint
- **Dependencies**: Zero. Node.js stdlib only.
- **Hosting**: Uberspace shared hosting, supervisord, Apache reverse proxy

## License

Private / personal use.
